#pragma once
#include "physics.h"
#include "tilemap.h"
#include "toggle.h"
#include "vec.h"

class Graphics;
class Color;
class Sprite;
class GameObject;

class Camera {
public:
    Camera(Graphics& graphics, float tilesize);

    void update(const Vec<float>& new_location, float dt);
    Vec<float> world_to_screen(const Vec<float>& world_position) const;
    void set_location(const Vec<float>& new_location);
    void handle_input();

    void render(const Vec<float>& position, const Color& color, bool filled=true) const;
    void render(const Tilemap& tilemap) const;
    void render(const Vec<float>& position, const Sprite& sprite, bool flash=false)const;
    void render(const GameObject& obj) const;
    void render(const std::vector<Background>& backgrounds) const;
    void render_game_over();
    void render_game_win();

private:
    Graphics& graphics;
    float tilesize;
    Vec<float> location;
    Toggle grid_toggle;

    void calculate_visible_tiles();
    Vec<int> visible_min, visible_max;
    Vec<float> goal;
    Physics physics;
};