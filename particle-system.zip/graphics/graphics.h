#pragma once

#include <SDL3/SDL.h>
#include <string>
#include <vector>

class Color {
public:
    int red{255}, green{0}, blue{255}, alpha{255};
};

class Graphics {
public:
    Graphics(std::string title, int width, int height);
    void draw(const SDL_FRect& rect, const Color& color, bool filled=true);

    void draw(const std::vector<SDL_Vertex>& vertexes);
    
    void clear();
    void update();

    const int width;
    const int height;

private:
    SDL_Window* window;
    SDL_Renderer* renderer;
};
