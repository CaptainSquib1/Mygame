#include "graphics.h"
#include <SDL3/SDL_render.h>
#include <stdexcept>

Graphics::Graphics(std::string title, int width, int height)
    : width{width}, height{height} {
    // Set up window/renderer
    SDL_SetAppMetadata(title.data(), "1.0", NULL);
    if (!SDL_CreateWindowAndRenderer(title.data(), width, height, SDL_WINDOW_RESIZABLE, &window, &renderer)) {
        SDL_Log("Couldn't create window/renderer: %s", SDL_GetError());
    }
    SDL_SetRenderLogicalPresentation(renderer, width, height, SDL_LOGICAL_PRESENTATION_LETTERBOX);

    // Added for alpha channel
    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
}

void Graphics::draw(const SDL_FRect& rect, const Color& color, bool filled) {
    auto [red, green, blue, alpha] = color;
    SDL_SetRenderDrawColor(renderer, red, green, blue, alpha);
    if (filled) {
        SDL_RenderFillRect(renderer, &rect);
    }
    else {
        SDL_RenderRect(renderer, &rect);
    }
}

void Graphics::draw(const std::vector<SDL_Vertex>& vertexes) {
    SDL_RenderGeometry(renderer, nullptr, vertexes.data(), static_cast<int>(vertexes.size()),
                       nullptr, 0);
}


void Graphics::clear() {
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderClear(renderer);
}

void Graphics::update() {
    SDL_RenderPresent(renderer);
}


