#include <SDL3/SDL_events.h>
#define SDL_MAIN_USE_CALLBACKS 1
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>

#include "particle_system.h"
#include "graphics.h"
#include "random.h"

// windowing
auto title = "ParticleSystem";
int width = 1280;
int height = 720;
SDL_Window* window;
SDL_Renderer* renderer;


struct App {
    double dt;
    Uint64 performance_frequency;
    Uint64 prev_counter;
    double lag;
    
    // particle system
    ParticleSystem* ps;
    Graphics* graphics;
};

SDL_AppResult SDL_AppInit(void **appstate, int, char**) {
    if (!SDL_Init(SDL_INIT_VIDEO)) {
        SDL_Log("Couldn't initialize SDL: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }


    App* app = new App();
    *appstate = app;
    
    // Set up window/renderer
    app->graphics = new Graphics("ParticleSystem", 1280, 720);
    app->ps = new ParticleSystem(1'000'000);

    app->dt = 1.0 / 60.0; // 60 FPS fixed step
    app->lag = 0.0;
    app->performance_frequency = SDL_GetPerformanceFrequency();
    app->prev_counter = SDL_GetPerformanceCounter();
    
    return SDL_APP_CONTINUE;
}

void fire_weapon(App* app, float x, float y) {
    Vec<float> position = { x, y };
    Vec<float> accel = {0, 0};
    Color color = { 255, 100, 0, 255 };
    for (int i = 0; i < 1000; ++i) {
        Vec<float> velocity = {600, 0};
        velocity += 165.0f * random_unit_vec() * random_float();
        Physics physics{position + Vec<float>{i*0.5f, 0}, velocity, accel};
        float lifetime = 0.25f * random_float();
        app->ps->create_particle(physics, lifetime, color);
    }
}

void explosion(App* app, float x, float y) {
    Vec<float> position = { x, y };
    Vec<float> accel = {0, 0};
    Vec<float> velocity = {0, 0};
    
    Color color = { 255, 100, 0, 255 };
    for (int i = 0; i < 100; ++i) {
        Vec<float> spread = 75.0f * random_unit_vec() * random_float();
        Physics physics{position, spread, accel};
        float lifetime = 1.0f * random_float();
        app->ps->create_particle(physics, lifetime, color);

        // later particles accumulate velocity via random walk
        velocity += spread;
        physics.velocity = velocity;
        lifetime = 1.0f * random_float();
        app->ps->create_particle(physics, lifetime, color);
    }
}

void fireworks(App* app, float x, float y) {
    Vec<float> position = { x, y };
    Vec<float> accel = {0, 400};
    Vec<float> velocity = {0, -300};
    
    Color color = { 255, 100, 0, 255 };
    for (int i = 0; i < 1000; ++i) {
        Vec<float> spread = 200.0f * random_unit_vec() * random_float();
        Physics physics{position, velocity + spread, accel};
        float lifetime = 4.0f * random_float();
        app->ps->create_particle(physics, lifetime, color);
    }
}

SDL_AppResult SDL_AppEvent(void* appstate, SDL_Event *event) {
    auto app = static_cast<App*>(appstate);
    
    if (event->type == SDL_EVENT_QUIT) {
        return SDL_APP_SUCCESS;
    }

    if (event->type == SDL_EVENT_MOUSE_BUTTON_DOWN) {
      //explosion(app, event->button.x, event->button.y);
      fire_weapon(app, event->button.x, event->button.y);
      //fireworks(app, event->button.x, event->button.y);

    }
    
    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppIterate(void *appstate) {
    auto app = static_cast<App*>(appstate);
    
    // update physics
    Uint64 now = SDL_GetPerformanceCounter();
    app->lag += ((now - app->prev_counter) / static_cast<double>(app->performance_frequency));
    app->prev_counter = now;
    while (app->lag >= app->dt) {
        app->ps->update(app->dt);
        app->lag -= app->dt;
    }

    // redraw particles
    app->graphics->clear();
    auto vertex = app->ps->render();
    app->graphics->draw(vertex);

    app->graphics->update();
    
    return SDL_APP_CONTINUE;
}

void SDL_AppQuit(void *appstate, SDL_AppResult) {
    auto app = static_cast<App*>(appstate);
    delete app->graphics;
    delete app->ps;
    delete app;
}
